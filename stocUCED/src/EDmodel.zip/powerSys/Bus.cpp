//
//  Bus.cpp
//  Stoch-UC
//
//  Created by Semih Atakan on 12/14/17.
//  Copyright © 2017 University of Southern California. All rights reserved.
//

#include "Bus.hpp"

Bus::Bus() {}
