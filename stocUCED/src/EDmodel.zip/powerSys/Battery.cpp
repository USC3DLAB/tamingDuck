//
//  Battery.cpp
//  tamingDuck
//
//  Created by Semih Atakan on 1/20/19.
//  Copyright © 2019 Semih Atakan. All rights reserved.
//

#include "Battery.hpp"

Battery::Battery() {
}
